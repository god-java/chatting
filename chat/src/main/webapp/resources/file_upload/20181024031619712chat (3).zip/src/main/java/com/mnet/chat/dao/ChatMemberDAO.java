package com.mnet.chat.dao;

import java.util.ArrayList;

import com.mnet.chat.dto.ChatMemberDTO;

public interface ChatMemberDAO {
	public void add_member(int sender_num, int member_num);
	public ArrayList<ChatMemberDTO> cm_member_info(int member_num);
	public ArrayList<ChatMemberDTO> cm_member_info2(int cr_num, int member_num);
	public ArrayList<Integer> find_member_num(int cr_num);
}
