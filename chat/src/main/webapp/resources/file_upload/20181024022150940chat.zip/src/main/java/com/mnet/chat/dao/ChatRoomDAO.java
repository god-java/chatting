package com.mnet.chat.dao;

import com.mnet.chat.dto.ChatRoomDTO;

public interface ChatRoomDAO {

	public void make_room(ChatRoomDTO crdto);
	public int overlap_room(ChatRoomDTO crdto);
	public int max_cr_num();
	public int find_cr_num(ChatRoomDTO crdto);
}
