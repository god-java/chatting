package com.mnet.chat;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mnet.chat.dao.ChatContentDAO;
import com.mnet.chat.dao.ChatMemberDAO;
import com.mnet.chat.dao.ChatRoomDAO;
import com.mnet.chat.dto.ChatContentDTO;
import com.mnet.chat.dto.ChatMemberDTO;
import com.mnet.chat.dto.ChatRoomDTO;

@Controller
public class ChatRoomController extends ObjectController {

	@RequestMapping(value="/room_list")
	@ResponseBody
	public String room_list(int member_num) {
		crdao = sst.getMapper(ChatRoomDAO.class);
		cmdao = sst.getMapper(ChatMemberDAO.class);
		ccdao = sst.getMapper(ChatContentDAO.class);
		String json="";
		ObjectMapper mapper = new ObjectMapper();
		ArrayList<ChatRoomDTO> crlist = crdao.room_list(member_num);
		ArrayList<ChatMemberDTO> cmlist = cmdao.cm_member_info(member_num);
		for(ChatRoomDTO crdto : crlist) {
			ArrayList<ChatMemberDTO> list = cmdao.cm_member_info2(crdto.getCr_num(), member_num);
			ChatContentDTO ccdto = ccdao.content_info(crdto.getCr_num());
			String cr_name = "";
			for(ChatMemberDTO dto : list) {
				cr_name += dto.getName()+",";
			}
			crdto.setCr_name(cr_name.substring(0,cr_name.length()-1));
			crdto.setProfile_image(list.get(0).getProfile_image());
			crdto.setCc_content(ccdto.getCc_content());
			crdto.setSend_date(ccdto.getSend_date());
		}
		/*for(ChatRoomDTO crdto : crlist) {
			for(ChatMemberDTO cdto : cmlist) {
				if(crdto.getCr_num() == cdto.getCr_num()) {
					crdto.setProfile_image(cdto.getProfile_image());
					crdto.setId(cdto.getId());
						String cr_name = "";
						for(ChatMemberDTO cdto2 : cmlist) {
							cr_name += cdto2.getId()+",";
						}
						crdto.setCr_name(cr_name.substring(0,cr_name.length()-1));
				}
			}
		}*/
		try {
			json = mapper.writeValueAsString(crlist);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(ChatRoomDTO crdto : crlist) {
			System.out.println(crdto.getId());
			System.out.println(crdto.getProfile_image());
			System.out.println(crdto.getCr_name());
		}
		return json;
		
	}
}
