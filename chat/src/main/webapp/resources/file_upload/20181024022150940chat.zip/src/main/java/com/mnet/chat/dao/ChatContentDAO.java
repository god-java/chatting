package com.mnet.chat.dao;

import java.util.ArrayList;

import com.mnet.chat.dto.ChatContentDTO;

public interface ChatContentDAO {
	public void add_content(ChatContentDTO ccdto);
	public ArrayList<ChatContentDTO> content_list(ChatContentDTO ccdto);
	public ArrayList<ChatContentDTO> test_list(ChatContentDTO ccdoo);
	public ArrayList<ChatContentDTO> chat_scroll(ChatContentDTO ccdoo);
}
