package com.mnet.chat;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mnet.chat.dao.FriendDAO;
import com.mnet.chat.dto.FriendDTO;

@Controller
public class FriendController extends ObjectController {

	@RequestMapping(value="/add_friend")
	public void add_friend(FriendDTO fdto, HttpServletResponse resp) throws IOException {
		fdao = sst.getMapper(FriendDAO.class);
		fdao.add_friend(fdto);
		resp.getWriter().print(1);
	}
	@RequestMapping(value="/delete_friend")
	public void delete_friend(FriendDTO fdto, HttpServletResponse resp) throws IOException {
		fdao = sst.getMapper(FriendDAO.class);
		fdao.delete_friend(fdto);
		resp.getWriter().print(1);
	}
}
