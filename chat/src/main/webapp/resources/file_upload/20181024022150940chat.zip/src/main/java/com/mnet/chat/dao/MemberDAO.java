package com.mnet.chat.dao;

import java.util.ArrayList;

import com.mnet.chat.dto.MemberDTO;

public interface MemberDAO {

	public ArrayList<MemberDTO> member_list();
	public int login_ok(MemberDTO mdto);
	public MemberDTO member_info(String id);
}
