package com.mnet.chat;

import java.util.ArrayList;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mnet.chat.dao.MemberDAO;
import com.mnet.chat.dto.MemberDTO;

@Controller
public class MainController extends ObjectController {
	
	@RequestMapping(value="/main")
	public String main(Model m) {
		mdao = sst.getMapper(MemberDAO.class);
		ArrayList<MemberDTO> mlist = mdao.member_list();
		m.addAttribute("mlist",mlist);
		return "main";
	}
	
	@RequestMapping(value="/login")
	public String login(Model m) {
		m.addAttribute("center","login.jsp");
		return "main";
	}
}
