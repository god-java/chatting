package com.mnet.chat.dao;

public interface ChatMemberDAO {
	public void add_member(int sender_num, int member_num);
}
