package com.mnet.chat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mnet.chat.dao.ChatContentDAO;
import com.mnet.chat.dto.ChatContentDTO;

@Controller
public class ChatContentController extends ObjectController {

	@RequestMapping(value="/chat_content_list")
	@ResponseBody
	public String chat_content_list(ChatContentDTO ccdto) {
		ccdao = sst.getMapper(ChatContentDAO.class);
		Map<String,Object> map = new HashMap<String,Object>();
		String json="";
		ArrayList<ChatContentDTO> cclist = ccdao.test_list(ccdto);
		map.put("cclist", cclist);
		ObjectMapper mapper = new ObjectMapper();
		try {
			json = mapper.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return json;
	}
	@RequestMapping(value="/chat_input")
	@ResponseBody
	public String chat_input(ChatContentDTO ccdto) {
		ccdao = sst.getMapper(ChatContentDAO.class);
		Map<String,Object> map = new HashMap<String,Object>();
		String json="";
		ArrayList<ChatContentDTO> cclist = ccdao.content_list(ccdto);
		map.put("cclist", cclist);
		ObjectMapper mapper = new ObjectMapper();
		try {
			json = mapper.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return json;
	}
}
